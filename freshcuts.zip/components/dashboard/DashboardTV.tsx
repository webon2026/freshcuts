'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Appointment, Barber, Product } from '@/types';
import { formatPrice, formatTime, BARBER_STATUS_LABELS } from '@/lib/utils';

const LOGO_SRC = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/7QCEUGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAGgcAigAYkZCTUQwYTAwMGFiNDAxMDAwMGM0MDIwMDAwZWQwMzAwMDAxOTA0MDAwMDc3MDQwMDAwZTcwNjAwMDA4YjA5MDAwMGU1MDkwMDAwMjIwYTAwMDA2NDBhMDAwMGJlMGMwMDAwAP/bAIQABQYGCwgLCwsLCw0LCwsNDg4NDQ4ODw0ODg4NDxAQEBEREBAQEA8TEhMPEBETFBQTERMWFhYTFhUVFhkWGRYWEgEFBQUKBwoICQkICwgKCAsKCgkJCgoMCQoJCgkMDQsKCwsKCw0MCwsICwsMDAwNDQwMDQoLCg0MDQ0MExQTExOc/8IAEQgAlgCWAwEiAAIRAQMRAf/EAH8AAQACAwEBAAAAAAAAAAAAAAAGBwEEBQIDEAABAwICBgcGBAQHAAAAAAABAgMRAAQSIRMxQVFhcQUUICIwgaEjQEKRscEQYNHwUFJy8SQyQ1Ni4eIRAQABAwIEBQQDAQAAAAAAAAERACExQVFhcYGRIDChsfAQQMHhYNHxUP/aAAwDAQACAAMAAAABpgAAAAAAAAC56YucpgAAAAAAAAC56YucpgAAA7OHU+fXj/z9avJmEP8AWA94AAXPTFzlMAPpIfOY1mc9zzmqupZHkj0Zkny8sQ+Sypmr8TJnENS2PesaY94XPTFzlMbWr2SabOnzvn69zqL72cQWSc/dO7rRbmZSP4x7vkc6Pf8AuZxzuZgjMljXrC56YufKmAS2OarDd1fAm+lytf5+utvxz2SjV4vwxn3z/r8Pr43+9EhKYsC56YufKmAAAAdTHMYbukAZAALnpi5ymAAAAAAAAALnpi5ymAAAAAAAAALnpi5ymFzimFzimFzimFzimFzimFzimFzimFzimFzimLnD/9oACAEBAAEFAvyo3ZJSmLZVXFsWfcLJGN24tlXC02k0B7Px7YlC79LiT1h00Wiy1HhAE010a65XUGm6atmTTmNkLF0A7d3DJaunHVdedBi4Sk3TRrDarpXR9LZUnstNKdNpZLt6QlDqesWhK1C1ZbvCh15nrRvLZDyej7RpD3RwHWLN9b91dKxO9Gsh1+3YtbiuqqVVz0c4yPxsrjQO9MPQeh1StiztVOJdF6ldiygW3VWjf3aX02VxoHW7gtOuOspLvR6bmkNosEWXs7fo+4DSrlDlsexdPJeZadLalvFSyZq36PDjdnaJdW5aBDl7YhgDo4aKysUvU6nQqJmtOrBartyi/uEOeCi7cQG3lN0X1KU5cLcHW3IQ+tAWsrPjC5NdYMuOlf57/9oACAEDAAE/AfdxWqj2gJrDXnRijFYeNR2J2dqe1IyyqRnlyqRll4M/wT//2gAIAQIAAT8B93JjPdQE5yRy2Ug6wdnaUoDWYrSTqBPlRJPw+tJkCIB86TiGyZ41pN6T9fpQcB29jBnMZ/hlQrdU0Uzrz7WFXe72vVwrCru97nxrCrPvcqHgR/BP/9oACAEBAAY/AvypjeVgB1Daf3+zUSpPE/3NbwdR9wSKkKynCnIkDcMvXjUYhjMwNkJmc/KinFjTEpP9+I9fcEqg5VjSVaM55fCTs/ThUYlZ1nOJWz+X9/p4eWdao517V4ch/wBYq7jDrvHDCfmox6VItkjhjBPyRFTo2hHwyCr5FRoYwEyNwGR5UEtoTjVyH6VEJn+kViWyj+mSFGf+Mz6VC2YPl9xPrX+Yo5z/AOq9msL/AHwmsx2cKElR3CiVrbbkbe+R5Du/M06t11xxLatQOFOE6jAn0rDoIT/MCcQ46zQCwV6IqRr4ynLkd9BzMpSqcJNFxh7Ef9s91Y5bDTJW8G/ZJ1idg4ikKTcBZE93DE5HjTij/ppWtPMU3JOawY5Z04d6jSArNOZVyAmoGNC0pKiUndz/AFoaJ4PDbiywjeTn9ax5KTtUgyBz2jsIXsBz5HX6VocAgZg/Tjq40to6nUEeYzH3qErWook4DHew7Jq4RiCe+FDF8j9BR/xIKtgCdvmftSXdIsqTnhIjPyzpuJlAikrImJ9QRWkTsNJeZlDgUDg+HyrSMLTCsyhRjCfpS1FYU6pJSMOoA/WrhzfDY88z9qUFzgcThJGscRRRixIWJB2KT2WTPtGxgVyGr0oKTkUmRWPUZnKudKVjB3a+7GZnyqMY7p1Z94DdWAuJHzy3TQOIagIzkq2xWPSJ34s4w7dk66JxgxPdzngaKQuY14Z/DR/DOLzrA8kgzktOv7/Sm0NjuNiB4KQlUBM5c9++jhMYhHlQWc1CPTVUKUVZ4s99Ri7uHDGyDRCTExMcKKjrOvx9lTA1RtoTs/Pf/9oACAEBAQE/If4oD/zhjPPAaytQmGxBjrHs08Tqhwj6ctHvHniliZ7Y9aVsUCLwSWUREtCFMMzVrnSBugmFm5DY3gqeOBGEiJUgCZOrd+wGCCvAtmzV3dRkhfKiIvdOYbWvZU8TdX1vtS4KnIywdHZhVNJGZhRkjynYCtglrFRfGCU6xWmbuC9p/ahBOcXrqqTkvAy/GZmnskJYVHUOGaHLoAEbmefD1KMssEXbTn+1XigtF7lamwxaLhAIDlfFElZMMMhM2GjTv4B6kfap7hcEfcu4Vkz39vCNQdCWsN0Jhr5D4ookLiNASg7EQdahpnYi5OIGNkq76VECQsEyfooHRgowabcqeyVI0UMCbHBFp9jhVM+0U/l0B8ynzxUEpRmdu25KnKnGNdDF3djLXFl+tFEDCcSl7VIDbFAZsBtoQKnlpLDZZk2YLS4UlUd1CdHUPB/c62j3NG8OAezkN12OFFOcfv8ApjuqGGlMayDjFyFjFKNKvI0kgFtg0sNT2ANgNl5YmkfRAAATVkidAvvQ6QhyZNHrtpvRRYjjrnSZoxnVOI5HmWqeca77ndE6SkUgkvcVLoMSJxh4UILxuykLEncICbrXGZbx/BKQ5HWy6I241jBJ3Q2ScO5p4YErAcuab7qT6ETiUkN/UEPCZaVKqtyutD1yEoE9TPRO9K5ZIwnlYe8UdaOqRnhAym08ajFaBBZ2Y5xS4klxxgQOpyaRWJhCABRMURN88KUQVigJ1NMUlyy8aAc77XJFQ4lKkv0bB69VBJC2brLLdiZb4OHksgYgYXKG4tfSshshMyZQcmNKa3BKTO9vgzSwQvURWY2nbFACaC7+tiVvOZp25awLovmCcVfZWViVy+eECLCMXxGcltooHIQ5B1zxoUQ2wRn+d//aAAwDAQECAQMBAAAQ888888888o888888888o8885b9888o8wqEXUex8o8guOYAe1/o8++pLSdP8A6PPPPLXvPPKPPPPPPPPPKPPPPPPPPPKMMMMMMMMMIP/aAAgBAwEBPxD7cShvWyB50dtfEuBNMModaAP6FSax0qTWI4VwB9PelmTxV/pvUV2eLoGeNfAWroGf+a//2gAIAQIBAT8Q+3iKwF7VFlUFdR8niwpzMUDuAUd2CpQ5GR+J+qAOSMPkf3VixO2Hs+SQW/SB5AILnqqPHGgj/h//2gAIAQEBAT8Q/inNUK5LLj0EqPhJKINZCByERJLk3F0LoYH2D9Kyz7H0zAO99OwADE5S7v7mc9dHIdSTrALk+wD02+WAaDJXDENBp/0GgpvWqE8k1M4LpNWOjBCIsU7AGYTmI8o084UnQlrqLMpOY9Ipo3Z7cndPr0yc0VpU5kq2KghCJ3scm4zclCZ/YaKSttsa1ZJ7f9guaeg5TWwlH4FKZFLMQQSbUM2O20JS1fMNVjRqWd8OvhwFHVEZbYDVbFcRNjzRV+gVB1SkTIw3lXmZH9VUVYohbqd1iGluJluvFq+IDTSzc4V6J3NHlv3p+VLDo7B2K4jWgPqBxKnfkg6d3ELXyAHWsvCCfOdlctVxs+bDKrYhMd6FdZKasHBKsBLqwx8fBsQQfFOooRa+89pRvQWbBCWkDZYAU4GhiqBs4oJ0du0Le5TUAVNLpFY9JKcnodokHtSmmoJY6NY1SUBh/QlrFPxl7dgNlkVJXup6B6l4WaUuj8R+0QogJStk1oTUwfldhqGvYAq2EOrS6rb/ACYIzLv4blKZpOO0OSuFvQKIhNKTnHqUm4lSVLKu8tCWkgVkVQx5stluP1taZIuS5IqOBTLJ1e4qZupt+qAoTkqH+ihhpI5alzExCOqjd2lISkyqXu1HZDyT1EXA00qx4pBcOxpQeAIrcUhJKrGg38iCKdhm/qB0VP5It8RqAhOUWrGBlvwWBui9aEYIHItGoaC1F8B1uRFzIl1lOpSrvOKchOic0xgoQNiC0rd4+fY/5nqaTRR80Hf+zUvR62kVxxdv53//2Q==';

const PRODUCT_INTERVAL = 5000;
const PRODUCTS_PER_PAGE = 4;

export default function DashboardTV() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [barbers, setBarbers]           = useState<Barber[]>([]);
  const [products, setProducts]         = useState<Product[]>([]);
  const [settings, setSettings]         = useState<Record<string,string>>({});
  const [time, setTime]                 = useState(new Date());
  const [productIdx, setProductIdx]     = useState(0);
  const [productFade, setProductFade]   = useState(true);
  const productTimer = useRef<NodeJS.Timeout | null>(null);
  const [barberiaIdx, setBarberiaIdx]   = useState(0);
  const [ropaIdx, setRopaIdx]           = useState(0);
  const [barberiaFade, setBarberiaFade] = useState(true);
  const [ropaFade, setRopaFade]         = useState(true);
  const barberiaTimer = useRef<NodeJS.Timeout | null>(null);
  const ropaTimer     = useRef<NodeJS.Timeout | null>(null);

  const CAT_BARBERIA = 'e7f975e0-6a8c-41da-ab44-97e47e780fda';
  const CAT_ROPA     = 'e83f91e9-82ac-4a59-bc68-aa5b7d8d68ad';

  // ── Loaders ──────────────────────────────────────────────
  const loadAppointments = useCallback(async () => {
    const today   = new Date().toISOString().slice(0, 10);
    const nowTime = new Date().toTimeString().slice(0, 5);
    const { data } = await supabase
      .from('appointments')
      .select('*, barber:barbers(*), service:services(*)')
      .eq('appointment_date', today)
      .eq('status', 'confirmed')
      .gte('appointment_time', nowTime)
      .order('appointment_time');
    if (data) setAppointments(data as Appointment[]);
  }, []);

  const loadBarbers = useCallback(async () => {
    const { data } = await supabase
      .from('barbers').select('*')
      .eq('active', true).eq('role', 'barber').order('sort_order');
    if (data) setBarbers(data);
  }, []);

  const loadProducts = useCallback(async () => {
    const { data } = await supabase
      .from('products').select('*, category:categories(*)')
      .eq('active', true).gt('stock', 0).order('sort_order');
    if (data) { setProducts(data as Product[]); setProductIdx(0); }
  }, []);

  const loadSettings = useCallback(async () => {
    const { data } = await supabase.from('settings').select('key,value');
    if (data) { const m: Record<string,string> = {}; data.forEach(s => { m[s.key] = s.value; }); setSettings(m); }
  }, []);

  // Refs para realtime (evitar stale closures)
  const loadAppointmentsRef = useRef(loadAppointments);
  const loadBarbersRef      = useRef(loadBarbers);
  const loadProductsRef     = useRef(loadProducts);
  useEffect(() => { loadAppointmentsRef.current = loadAppointments; }, [loadAppointments]);
  useEffect(() => { loadBarbersRef.current      = loadBarbers; },      [loadBarbers]);
  useEffect(() => { loadProductsRef.current     = loadProducts; },     [loadProducts]);

  // ── Setup inicial + realtime ──────────────────────────────
  useEffect(() => {
    Promise.all([loadAppointments(), loadBarbers(), loadProducts(), loadSettings()]);

    const channel = supabase.channel(`dashboard-tv-${Date.now()}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'appointments' }, () => loadAppointmentsRef.current())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'barbers' },      () => loadBarbersRef.current())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' },     () => loadProductsRef.current())
      .subscribe();

    const clockTimer = setInterval(() => setTime(new Date()), 1000);
    // Refrescar citas cada minuto para que desaparezcan al pasar la hora
    const apptTimer  = setInterval(() => loadAppointmentsRef.current(), 60000);

    return () => {
      supabase.removeChannel(channel);
      clearInterval(clockTimer);
      clearInterval(apptTimer);
    };
  }, []); // eslint-disable-line

  // ── Carrusel productos ────────────────────────────────────
  useEffect(() => {
    const totalPages = Math.ceil(products.length / PRODUCTS_PER_PAGE);
    if (totalPages <= 1) return;
    if (productTimer.current) clearInterval(productTimer.current);
    productTimer.current = setInterval(() => {
      setProductFade(false);
      setTimeout(() => { setProductIdx(i => (i + 1) % totalPages); setProductFade(true); }, 500);
    }, PRODUCT_INTERVAL);
    return () => { if (productTimer.current) clearInterval(productTimer.current); };
  }, [products]);

  // ── Carrusel barbería (2 en 2) ───────────────────────────
  useEffect(() => {
    const barb = products.filter(p => p.category_id === CAT_BARBERIA);
    if (barb.length <= 2) return;
    if (barberiaTimer.current) clearInterval(barberiaTimer.current);
    barberiaTimer.current = setInterval(() => {
      setBarberiaFade(false);
      setTimeout(() => { setBarberiaIdx(i => (i + 2) % barb.length); setBarberiaFade(true); }, 400);
    }, 4000);
    return () => { if (barberiaTimer.current) clearInterval(barberiaTimer.current); };
  }, [products]);

  // ── Carrusel ropa (2 en 2) ───────────────────────────────
  useEffect(() => {
    const ropa = products.filter(p => p.category_id === CAT_ROPA);
    if (ropa.length <= 2) return;
    if (ropaTimer.current) clearInterval(ropaTimer.current);
    ropaTimer.current = setInterval(() => {
      setRopaFade(false);
      setTimeout(() => { setRopaIdx(i => (i + 2) % ropa.length); setRopaFade(true); }, 400);
    }, 5000);
    return () => { if (ropaTimer.current) clearInterval(ropaTimer.current); };
  }, [products]);

  // ── Helpers reloj ────────────────────────────────────────
  const hh = String(time.getHours()).padStart(2, '0');
  const mm = String(time.getMinutes()).padStart(2, '0');
  const days   = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  const dateStr = `${days[time.getDay()]} ${time.getDate()} de ${months[time.getMonth()]}`;

  const colorMap: Record<string,string> = { available:'#2ECC71', busy:'#E67E22', break:'#F1C40F', off:'#E74C3C' };

  const visibleProducts = products.slice(productIdx * PRODUCTS_PER_PAGE, productIdx * PRODUCTS_PER_PAGE + PRODUCTS_PER_PAGE);
  const totalPages = Math.ceil(products.length / PRODUCTS_PER_PAGE);

  return (
    <div style={{ width:'100vw', height:'100vh', background:'#0a0a0a', overflow:'hidden', display:'flex', flexDirection:'column', fontFamily:'Barlow, sans-serif', color:'white' }}>

      {/* Textura sutil */}
      <div style={{ position:'fixed', inset:0, backgroundImage:'repeating-linear-gradient(45deg,transparent,transparent 40px,rgba(201,168,76,0.008) 40px,rgba(201,168,76,0.009) 41px)', pointerEvents:'none', zIndex:0 }} />

      {/* ══ HEADER ══ */}
      <div style={{ position:'relative', zIndex:1, background:'linear-gradient(180deg,#111,#0d0d0d)', borderBottom:'2px solid rgba(201,168,76,0.5)', flexShrink:0 }}>
        <div style={{ display:'flex', alignItems:'center', gap:28, height:86, padding:'0 40px' }}>

          {/* Logo */}
          <div style={{ display:'flex', alignItems:'center', gap:14, flexShrink:0 }}>
            <img src={LOGO_SRC} alt="Fresh Cuts" style={{ height:66, width:66, borderRadius:'50%', objectFit:'cover', border:'2px solid rgba(201,168,76,0.5)', boxShadow:'0 0 18px rgba(201,168,76,0.2)' }} />
            <div>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:36, color:'#C9A84C', letterSpacing:6, lineHeight:1, textShadow:'0 0 20px rgba(201,168,76,0.35)' }}>FRESH CUTS</div>
              <div style={{ fontFamily:'Barlow Condensed', fontSize:10, color:'rgba(255,255,255,0.3)', letterSpacing:5, marginTop:2 }}>SALÓN · SINCE 2018</div>
            </div>
          </div>

          <div style={{ width:1, height:50, background:'rgba(201,168,76,0.2)', flexShrink:0 }} />

          {/* Barberos */}
          <div style={{ flex:1, display:'flex', alignItems:'center', gap:10, overflow:'hidden' }}>
            <div style={{ fontFamily:'Barlow Condensed', fontSize:10, letterSpacing:4, color:'rgba(201,168,76,0.4)', flexShrink:0 }}>EQUIPO</div>
            <div style={{ display:'flex', gap:8, overflow:'hidden' }}>
              {barbers.map(b => {
                const bc = colorMap[b.status] || '#888';
                const sl = BARBER_STATUS_LABELS[b.status];
                return (
                  <div key={b.id} style={{ display:'flex', alignItems:'center', gap:8, background:'rgba(255,255,255,0.03)', border:`1px solid ${bc}30`, borderRadius:28, padding:'5px 14px 5px 7px', flexShrink:0 }}>
                    <div style={{ width:32, height:32, borderRadius:'50%', background:`${bc}15`, border:`2px solid ${bc}50`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:17 }}>{b.avatar_emoji}</div>
                    <div>
                      <div style={{ fontFamily:'Barlow Condensed', fontSize:15, fontWeight:700, letterSpacing:0.5, lineHeight:1 }}>{b.name}</div>
                      <div style={{ display:'flex', alignItems:'center', gap:4, marginTop:3 }}>
                        <div style={{ width:6, height:6, borderRadius:'50%', background:bc, boxShadow:b.status==='available'?`0 0 6px ${bc}`:'none' }} />
                        <span style={{ fontSize:10, color:bc, fontFamily:'Barlow Condensed', letterSpacing:1 }}>{sl?.label || b.status}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Reloj */}
          <div style={{ textAlign:'right', flexShrink:0 }}>
            <div style={{ fontFamily:'Bebas Neue', fontSize:50, letterSpacing:4, lineHeight:1 }}>{hh}:{mm}</div>
            <div style={{ fontFamily:'Barlow Condensed', fontSize:11, color:'rgba(255,255,255,0.35)', letterSpacing:3, textTransform:'uppercase', marginTop:2 }}>{dateStr}</div>
          </div>
        </div>
      </div>

      {/* ══ BODY ══ */}
      <div style={{ flex:1, display:'grid', gridTemplateColumns:'300px 1fr', minHeight:0, position:'relative', zIndex:1 }}>

        {/* ── IZQUIERDA: Citas ── */}
        <div style={{ display:'flex', flexDirection:'column', borderRight:'1px solid rgba(201,168,76,0.15)', background:'rgba(0,0,0,0.3)', overflow:'hidden' }}>
          <div style={{ padding:'18px 20px 12px', borderBottom:'1px solid rgba(201,168,76,0.1)', flexShrink:0 }}>
            <div style={{ fontFamily:'Barlow Condensed', fontSize:10, letterSpacing:5, color:'rgba(201,168,76,0.5)', display:'flex', alignItems:'center', gap:8 }}>
              📅 PRÓXIMAS CITAS
              <div style={{ flex:1, height:1, background:'linear-gradient(90deg,rgba(201,168,76,0.2),transparent)' }} />
            </div>
          </div>

          <div style={{ flex:1, overflowY:'hidden', display:'flex', flexDirection:'column' }}>
            {appointments.length === 0 ? (
              <div style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:10, color:'rgba(255,255,255,0.15)' }}>
                <div style={{ fontSize:36 }}>✅</div>
                <div style={{ fontFamily:'Barlow Condensed', fontSize:13, letterSpacing:2, textAlign:'center', lineHeight:1.4 }}>SIN CITAS<br/>CONFIRMADAS</div>
              </div>
            ) : appointments.map((a, i) => {
              const isFirst = i === 0;
              return (
                <div key={a.id} style={{ padding:'14px 20px', borderBottom:'1px solid rgba(255,255,255,0.04)', borderLeft:`3px solid ${isFirst ? '#C9A84C' : 'rgba(255,255,255,0.08)'}`, background:isFirst ? 'rgba(201,168,76,0.05)' : 'transparent', flexShrink:0 }}>
                  <div style={{ fontFamily:'Bebas Neue', fontSize:isFirst?34:28, color:isFirst?'#C9A84C':'rgba(255,255,255,0.35)', letterSpacing:2, lineHeight:1, marginBottom:4 }}>
                    {formatTime(a.appointment_time)}
                  </div>
                  <div style={{ fontFamily:'Barlow Condensed', fontSize:isFirst?20:16, fontWeight:700, textTransform:'uppercase', color:isFirst?'white':'rgba(255,255,255,0.6)', letterSpacing:0.5, lineHeight:1, marginBottom:6 }}>
                    {a.client_name}
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:5, marginBottom:3 }}>
                    <span style={{ fontSize:14 }}>{(a.barber as any)?.avatar_emoji || '✂️'}</span>
                    <span style={{ fontFamily:'Barlow Condensed', fontSize:12, color:isFirst?'#C9A84C':'rgba(201,168,76,0.5)', letterSpacing:0.5 }}>{a.barber?.name}</span>
                  </div>
                  <div style={{ fontFamily:'Barlow Condensed', fontSize:11, color:'rgba(255,255,255,0.3)', letterSpacing:0.5 }}>{a.service?.name}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── DERECHA: Dos secciones por categoría ── */}
        {(() => {
          const barberia = products.filter(p => p.category_id === CAT_BARBERIA);
          const ropa     = products.filter(p => p.category_id === CAT_ROPA);
          const bLen  = barberia.length;
          const rLen  = ropa.length;
          const bPair = bLen === 0 ? [] : bLen === 1 ? [barberia[0]] : [barberia[barberiaIdx % bLen], barberia[(barberiaIdx+1) % bLen]];
          const rPair = rLen === 0 ? [] : rLen === 1 ? [ropa[0]] : [ropa[ropaIdx % rLen], ropa[(ropaIdx+1) % rLen]];

          const SlideSection = ({ label, emoji, pair, fade, accentColor }: { label:string, emoji:string, pair:Product[], fade:boolean, accentColor:string }) => (
            <div style={{ flex:1, display:'flex', flexDirection:'column', minHeight:0 }}>
              {/* Label sección */}
              <div style={{ fontFamily:'Barlow Condensed', fontSize:10, letterSpacing:5, color:accentColor, marginBottom:10, display:'flex', alignItems:'center', gap:8, flexShrink:0 }}>
                {emoji} {label}
                <div style={{ flex:1, height:1, background:`linear-gradient(90deg,${accentColor}40,transparent)` }} />
              </div>
              {/* Imágenes lado a lado */}
              <div style={{ flex:1, minHeight:0, display:'grid', gridTemplateColumns: pair.length===1?'1fr':'1fr 1fr', gap:10, opacity:fade?1:0, transition:'opacity 0.4s ease', position:'relative' }}>
                {pair.length === 0 ? (
                  <div style={{ borderRadius:14, background:'#111', display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:8, color:'rgba(255,255,255,0.1)' }}>
                    <div style={{ fontSize:36 }}>{emoji}</div>
                    <div style={{ fontFamily:'Barlow Condensed', fontSize:11, letterSpacing:3 }}>SIN PRODUCTOS</div>
                  </div>
                ) : pair.map((p, i) => (
                  <div key={`${p.id}-${i}`} style={{ position:'relative', borderRadius:14, overflow:'hidden', background:'#161616', minHeight:0 }}>
                    {p.image_url
                      ? <img src={p.image_url} alt={p.name} style={{ width:'100%', height:'100%', objectFit:'cover', objectPosition:'center', display:'block' }} />
                      : <div style={{ width:'100%', height:'100%', background:'linear-gradient(135deg,#1a1a1a,#222)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:40 }}>{emoji}</div>
                    }
                    <div style={{ position:'absolute', bottom:0, left:0, right:0, padding:'40px 16px 14px', background:'linear-gradient(0deg,rgba(0,0,0,0.93) 40%,transparent)' }}>
                      <div style={{ fontFamily:'Bebas Neue', fontSize:22, color:'white', letterSpacing:2, lineHeight:1 }}>{p.name}</div>
                      <div style={{ fontFamily:'Bebas Neue', fontSize:26, color:accentColor, letterSpacing:3, marginTop:2, textShadow:`0 0 16px ${accentColor}60` }}>{formatPrice(p.price)}</div>
                    </div>
                    {p.badge && (
                      <div style={{ position:'absolute', top:10, left:10, background:p.badge==='hot'?'#C0392B':accentColor, color:p.badge==='hot'?'white':'#000', fontSize:9, fontWeight:700, padding:'3px 8px', borderRadius:20, fontFamily:'Barlow Condensed', letterSpacing:1 }}>
                        {p.badge==='hot'?'🔥 POPULAR':'✨ NUEVO'}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );

          return (
            <div style={{ display:'flex', flexDirection:'column', overflow:'hidden', padding:'16px 24px 14px', gap:0, flex:1 }}>

              {/* ══ SECCIÓN SUPERIOR: Barbería ══ */}
              <SlideSection label="PRODUCTOS DE BARBERÍA" emoji="💈" pair={bPair} fade={barberiaFade} accentColor="#C9A84C" />

              {/* ── Separador onda animada (solo barras, sin ticker) ── */}
              <div style={{ flexShrink:0, height:48, margin:'10px 0', position:'relative', borderRadius:10, overflow:'hidden', background:'rgba(0,0,0,0.3)', border:'1px solid rgba(201,168,76,0.08)' }}>
                <style>{`
                  @keyframes wv1{0%,100%{height:8px}50%{height:38px}}
                  @keyframes wv2{0%,100%{height:20px}30%{height:6px}70%{height:42px}}
                  @keyframes wv3{0%,100%{height:32px}40%{height:8px}80%{height:26px}}
                  @keyframes wv4{0%,100%{height:12px}25%{height:40px}75%{height:10px}}
                  @keyframes wv5{0%,100%{height:26px}50%{height:6px}}
                  @keyframes wv6{0%,100%{height:10px}35%{height:36px}65%{height:14px}}
                  @keyframes wv7{0%,100%{height:38px}45%{height:8px}}
                  @keyframes wv8{0%,100%{height:16px}60%{height:38px}}
                `}</style>
                <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', gap:4, padding:'0 20px' }}>
                  {Array.from({ length:50 }).map((_,i) => {
                    const a = ['wv1','wv2','wv3','wv4','wv5','wv6','wv7','wv8'][i%8];
                    const mid = i>15 && i<35;
                    return <div key={i} style={{ width:4, borderRadius:2, background:mid?'#C9A84C':'rgba(201,168,76,0.25)', animation:`${a} ${(1.1+(i%6)*0.18).toFixed(2)}s ease-in-out ${(i*0.06).toFixed(2)}s infinite`, boxShadow:mid?'0 0 5px rgba(201,168,76,0.45)':'none', alignSelf:'center' }} />;
                  })}
                </div>
              </div>

              {/* ══ SECCIÓN INFERIOR: Ropa ══ */}
              <SlideSection label="TIENDA DE ROPA" emoji="👕" pair={rPair} fade={ropaFade} accentColor="#A89060" />

            </div>
          );
        })()}
      </div>

      {/* ══ FOOTER ══ */}
      <div style={{ position:'relative', zIndex:1, height:40, background:'#060606', borderTop:'1px solid rgba(201,168,76,0.12)', display:'flex', alignItems:'center', padding:'0 40px', flexShrink:0 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, flex:1 }}>
          <div style={{ width:6, height:6, borderRadius:'50%', background:'#2ECC71', boxShadow:'0 0 8px #2ECC71' }} />
          <span style={{ fontFamily:'Barlow Condensed', fontSize:11, color:'rgba(255,255,255,0.25)', letterSpacing:4 }}>EN VIVO</span>
        </div>
        <div style={{ fontFamily:'Barlow Condensed', fontSize:11, color:'rgba(255,255,255,0.2)', letterSpacing:3, textTransform:'uppercase' }}>
          {settings.business_name || 'FRESH CUTS'} · {settings.business_address || 'SANTIAGO, CHILE'}
        </div>
      </div>
    </div>
  );
}
