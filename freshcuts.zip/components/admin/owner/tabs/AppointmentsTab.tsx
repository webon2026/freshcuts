'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Appointment, AppointmentStatus } from '@/types';
import { STATUS_LABELS, formatPrice, formatTime, getSession } from '@/lib/utils';

const STATUS_ORDER: AppointmentStatus[] = ['pending','confirmed','in_progress','done','cancelled'];

function formatChilePhone(raw?: string): string {
  if (!raw) return '';
  const d = raw.replace(/\D/g, '');
  if (d.startsWith('569')) return d;
  if (d.startsWith('56')) return d;
  if (d.startsWith('9') && d.length === 9) return '56' + d;
  if (d.length === 8) return '569' + d;
  return d;
}

function formatDateLong(dateStr?: string) {
  if (!dateStr) return '';
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('es-CL', { weekday: 'long', day: 'numeric', month: 'long' });
}

// ─── Mensajes WSP por estado ───
function wspConfirmed(a: Appointment): string {
  return (
    'Hola ' + a.client_name + ', tu cita en Fresh Cuts ha sido *confirmada*.' + '%0A' +
    '%0A' +
    'Fecha: ' + formatDateLong(a.appointment_date) + '%0A' +
    'Hora: ' + (a.appointment_time?.slice(0,5) || '') + ' hrs' + '%0A' +
    'Servicio: ' + (a.service?.name || '') + '%0A' +
    '%0A' +
    'Te esperamos! Si necesitas reagendar avisanos con anticipacion.'
  );
}

function wspInProgress(a: Appointment): string {
  return (
    'Hola ' + a.client_name + '!' + '%0A' +
    '%0A' +
    'Estamos listos para atenderte. Te esperamos en Fresh Cuts.' + '%0A' +
    'Hoy a las ' + (a.appointment_time?.slice(0,5) || '') + ' hrs.' + '%0A' +
    '%0A' +
    'Nos vemos pronto!'
  );
}

function wspDone(a: Appointment): string {
  const precio = a.total_price ? '$' + Number(a.total_price).toLocaleString('es-CL') : '';
  return (
    'Hola ' + a.client_name + '!' + '%0A' +
    '%0A' +
    '*Comprobante de atencion - Fresh Cuts*' + '%0A' +
    '%0A' +
    'Servicio: ' + (a.service?.name || '') + '%0A' +
    'Barbero: ' + (a.barber?.name || '') + '%0A' +
    'Fecha: ' + formatDateLong(a.appointment_date) + '%0A' +
    'Hora: ' + (a.appointment_time?.slice(0,5) || '') + ' hrs' + '%0A' +
    'Total pagado: ' + precio + '%0A' +
    '%0A' +
    'Gracias por visitarnos, fue un placer atenderte!' + '%0A' +
    'Te esperamos pronto en Fresh Cuts.'
  );
}

function wspCancelled(a: Appointment): string {
  return (
    'Hola ' + a.client_name + ',' + '%0A' +
    '%0A' +
    'Tu cita del ' + formatDateLong(a.appointment_date) + ' a las ' + (a.appointment_time?.slice(0,5) || '') + ' hrs ha sido *cancelada*.' + '%0A' +
    '%0A' +
    'Puedes reservar una nueva hora cuando quieras en nuestro sitio web.' + '%0A' +
    'Disculpa los inconvenientes.'
  );
}

const WSP_MESSAGES: Partial<Record<AppointmentStatus, (a: Appointment) => string>> = {
  confirmed:   wspConfirmed,
  in_progress: wspInProgress,
  done:        wspDone,
  cancelled:   wspCancelled,
};

interface Props { isOwner?: boolean }

export default function AppointmentsTab({ isOwner = false }: Props) {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<AppointmentStatus | 'all'>('all');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0,10));
  const session = getSession();

  useEffect(() => {
    loadAppointments();
    const channel = supabase.channel('appt-tab')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'appointments' }, loadAppointments)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [selectedDate]);

  async function loadAppointments() {
    setLoading(true);
    let query = supabase.from('appointments')
      .select('*, barber:barbers(*), service:services(*)')
      .eq('appointment_date', selectedDate)
      .order('appointment_time');
    if (!isOwner && session?.barber_id) query = query.eq('barber_id', session.barber_id);
    const { data } = await query;
    if (data) setAppointments(data as Appointment[]);
    setLoading(false);
  }

  async function updateStatus(appt: Appointment, status: AppointmentStatus) {
    await supabase.from('appointments').update({ status }).eq('id', appt.id);

    const msgFn = WSP_MESSAGES[status];
    const waNum = formatChilePhone(appt.client_phone);
    if (msgFn && waNum) {
      const updated = { ...appt, status };
      const msg = msgFn(updated);
      window.open('https://wa.me/' + waNum + '?text=' + msg, '_blank');
    }

    loadAppointments();
  }

  const filtered = filter === 'all' ? appointments : appointments.filter(a => a.status === filter);

  const stats = {
    total: appointments.length,
    done: appointments.filter(a => a.status === 'done').length,
    pending: appointments.filter(a => ['pending','confirmed'].includes(a.status)).length,
    inProgress: appointments.filter(a => a.status === 'in_progress').length,
  };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h2 className="fc-title" style={{ fontSize: 26, color: 'var(--gold)' }}>
          {isOwner ? 'Todas las citas' : 'Mis citas'}
        </h2>
        <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)}
          className="fc-input" style={{ width: 'auto', fontSize: 13 }} />
      </div>

      {isOwner && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8, marginBottom: 18 }}>
          {[
            { label: 'Total',      value: stats.total,      color: 'var(--cream)' },
            { label: 'Pendientes', value: stats.pending,    color: '#F1C40F' },
            { label: 'Atendiendo', value: stats.inProgress, color: 'var(--green)' },
            { label: 'Atendidos',  value: stats.done,       color: 'var(--gray)' },
          ].map(s => (
            <div key={s.label} className="fc-card" style={{ padding: '12px 8px', textAlign: 'center' }}>
              <div className="fc-title" style={{ fontSize: 26, color: s.color }}>{s.value}</div>
              <div style={{ fontSize: 10, color: 'var(--gray)' }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{ display: 'flex', gap: 6, overflowX: 'auto', marginBottom: 14, paddingBottom: 4, scrollbarWidth: 'none' }}>
        {(['all', ...STATUS_ORDER] as const).map(s => (
          <button key={s} onClick={() => setFilter(s)}
            style={{ padding: '6px 12px', borderRadius: 20, border: 'none', cursor: 'pointer', flexShrink: 0, background: filter === s ? 'var(--gold)' : 'var(--card)', color: filter === s ? 'var(--black)' : 'var(--gray)', fontSize: 11, fontWeight: 600, transition: 'all 0.2s' }}>
            {s === 'all' ? 'Todas' : STATUS_LABELS[s]?.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--gray)' }}>Cargando...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--gray)' }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>📭</div>
          No hay citas para esta fecha
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(a => {
            const sl = STATUS_LABELS[a.status];
            return (
              <div key={a.id} className="fc-card" style={{ padding: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15 }}>{a.client_name}</div>
                    <div style={{ color: 'var(--gray)', fontSize: 12, marginTop: 2 }}>{a.client_phone}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div className="fc-title" style={{ fontSize: 22, color: 'var(--gold)' }}>{formatTime(a.appointment_time)}</div>
                    {isOwner && a.barber && <div style={{ fontSize: 11, color: 'var(--gray)' }}>{a.barber.name}</div>}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap', marginBottom: a.notes ? 8 : 10 }}>
                  <span style={{ background: 'rgba(201,168,76,0.1)', color: 'var(--gold)', padding: '3px 10px', borderRadius: 8, fontSize: 12 }}>{a.service?.name}</span>
                  <span style={{ background: 'rgba(255,255,255,0.05)', color: 'var(--gray)', padding: '3px 10px', borderRadius: 8, fontSize: 12 }}>{formatPrice(a.total_price)}</span>
                  <span className={sl?.color} style={{ padding: '3px 10px', borderRadius: 8, fontSize: 11, fontWeight: 700 }}>{sl?.label}</span>
                </div>

                {a.notes && <div style={{ color: 'var(--gray)', fontSize: 12, marginBottom: 10, fontStyle: 'italic' }}>{a.notes}</div>}

                {a.status !== 'done' && a.status !== 'cancelled' && (
                  <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap' }}>
                    {a.status === 'pending' && (
                      <button className="fc-btn-gold" style={{ padding: '7px 14px', fontSize: 12 }}
                        onClick={() => updateStatus(a, 'confirmed')}>
                        Confirmar
                      </button>
                    )}
                    {(a.status === 'confirmed' || a.status === 'pending') && (
                      <button className="fc-btn-gold" style={{ padding: '7px 14px', fontSize: 12 }}
                        onClick={() => updateStatus(a, 'in_progress')}>
                        En atencion
                      </button>
                    )}
                    {a.status === 'in_progress' && (
                      <button style={{ padding: '7px 14px', fontSize: 12, background: 'var(--green)', border: 'none', color: 'white', borderRadius: 8, cursor: 'pointer', fontWeight: 600 }}
                        onClick={() => updateStatus(a, 'done')}>
                        Listo — enviar comprobante
                      </button>
                    )}
                    <button style={{ padding: '7px 14px', fontSize: 12, background: 'rgba(231,76,60,0.1)', border: '1px solid rgba(231,76,60,0.3)', color: '#E74C3C', borderRadius: 8, cursor: 'pointer' }}
                      onClick={() => updateStatus(a, 'cancelled')}>
                      Cancelar
                    </button>
                  </div>
                )}

                {/* Si ya está listo, mostrar botón para reenviar comprobante */}
                {a.status === 'done' && (
                  <button style={{ padding: '6px 12px', fontSize: 11, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', color: 'var(--gray)', borderRadius: 8, cursor: 'pointer' }}
                    onClick={() => {
                      const waNum = formatChilePhone(a.client_phone);
                      if (waNum) window.open('https://wa.me/' + waNum + '?text=' + wspDone(a), '_blank');
                    }}>
                    Reenviar comprobante
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
