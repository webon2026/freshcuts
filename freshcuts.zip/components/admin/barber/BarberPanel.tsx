'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { AdminSession, Appointment, Barber, AppointmentStatus } from '@/types';
import { STATUS_LABELS, BARBER_STATUS_LABELS, formatPrice, formatTime } from '@/lib/utils';
import BlockSchedule from '@/components/admin/shared/BlockSchedule';

interface Props { session: AdminSession; onLogout: () => void; }

type Tab = 'appointments' | 'blocks';

const STATUS_OPTIONS: { value: Barber['status']; label: string; emoji: string; color: string }[] = [
  { value: 'available', label: 'Disponible',    emoji: '✅', color: 'var(--green)' },
  { value: 'busy',      label: 'En atención',   emoji: '✂️', color: '#E67E22' },
  { value: 'break',     label: 'Descanso',      emoji: '☕', color: '#F1C40F' },
  { value: 'off',       label: 'No disponible', emoji: '🔴', color: '#E74C3C' },
];

export default function BarberPanel({ session, onLogout }: Props) {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [barber, setBarber] = useState<Barber | null>(null);
  const [loading, setLoading] = useState(true);
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));
  const [tab, setTab] = useState<Tab>('appointments');
  const [showStatusPicker, setShowStatusPicker] = useState(false);

  useEffect(() => {
    loadBarber();
    loadAppointments();
    const channel = supabase.channel('barber_panel')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'appointments' }, loadAppointments)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [date]);

  async function loadBarber() {
    const { data } = await supabase.from('barbers').select('*').eq('id', session.barber_id).single();
    if (data) setBarber(data);
  }

  async function loadAppointments() {
    setLoading(true);
    const { data } = await supabase
      .from('appointments').select('*, service:services(*)')
      .eq('barber_id', session.barber_id).eq('appointment_date', date).order('appointment_time');
    if (data) setAppointments(data as Appointment[]);
    setLoading(false);
  }

  async function updateStatus(id: string, status: AppointmentStatus) {
    await supabase.from('appointments').update({ status }).eq('id', id);
    loadAppointments();
  }

  async function setMyStatus(status: Barber['status']) {
    await supabase.from('barbers').update({ status }).eq('id', session.barber_id);
    setBarber(b => b ? { ...b, status } : b);
    setShowStatusPicker(false);
  }

  const currentStatus = STATUS_OPTIONS.find(s => s.value === barber?.status);

  return (
    <div style={{ minHeight: '100vh', paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: 'var(--dark)', borderBottom: '1px solid rgba(201,168,76,0.2)', padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 50, gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <img src="/logo.jpg" alt="" style={{ width: 34, height: 34, borderRadius: '50%', objectFit: 'cover', border: '1px solid rgba(201,168,76,0.3)', flexShrink: 0 }} />
          <div>
            <div className="fc-title" style={{ fontSize: 16, color: 'var(--gold)', lineHeight: 1 }}>FRESH CUTS</div>
            <div className="fc-label" style={{ fontSize: 9, color: 'var(--gray)', letterSpacing: 2 }}>✂️ {session.name}</div>
          </div>
        </div>

        {/* Mi estado */}
        <div style={{ position: 'relative' }}>
          <button onClick={() => setShowStatusPicker(!showStatusPicker)}
            style={{ background: 'rgba(255,255,255,0.05)', border: `1px solid ${currentStatus?.color || 'rgba(255,255,255,0.1)'}`, borderRadius: 20, padding: '6px 12px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: currentStatus?.color || 'var(--gray)' }} />
            <span className="fc-label" style={{ fontSize: 10, color: currentStatus?.color || 'var(--gray)', letterSpacing: 1 }}>{currentStatus?.label || 'Estado'}</span>
            <span style={{ color: 'var(--gray)', fontSize: 10 }}>▾</span>
          </button>

          {showStatusPicker && (
            <div style={{ position: 'absolute', top: '110%', right: 0, background: '#1e1e1e', border: '1px solid rgba(201,168,76,0.2)', borderRadius: 12, padding: 8, zIndex: 100, boxShadow: '0 8px 30px rgba(0,0,0,0.5)', minWidth: 180 }}>
              {STATUS_OPTIONS.map(s => (
                <button key={s.value} onClick={() => setMyStatus(s.value)}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: barber?.status === s.value ? 'rgba(201,168,76,0.08)' : 'transparent', border: 'none', borderRadius: 8, cursor: 'pointer' }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: s.color, flexShrink: 0 }} />
                  <span style={{ color: s.color, fontSize: 13, fontWeight: 600, flex: 1, textAlign: 'left' }}>{s.label}</span>
                  {barber?.status === s.value && <span style={{ color: 'var(--gold)', fontSize: 12 }}>✓</span>}
                </button>
              ))}
              {/* Aviso "No disponible" */}
              {barber?.status === 'off' && (
                <div style={{ margin: '6px 12px 4px', padding: '8px', background: 'rgba(231,76,60,0.08)', borderRadius: 8, fontSize: 11, color: '#E74C3C', lineHeight: 1.4 }}>
                  ⚠️ Estás como No disponible. Los clientes no pueden reservar contigo hasta que cambies tu estado.
                </div>
              )}
              <div style={{ height: 1, background: 'rgba(255,255,255,0.05)', margin: '6px 0' }} />
              <button onClick={onLogout} style={{ width: '100%', padding: '8px 12px', background: 'transparent', border: 'none', color: 'var(--gray)', cursor: 'pointer', fontSize: 12, textAlign: 'left', borderRadius: 8 }}>
                Cerrar sesión
              </button>
            </div>
          )}
        </div>
      </div>

      {showStatusPicker && <div style={{ position: 'fixed', inset: 0, zIndex: 49 }} onClick={() => setShowStatusPicker(false)} />}

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.06)', background: 'var(--dark)', position: 'sticky', top: 58, zIndex: 40 }}>
        {([
          { id: 'appointments', label: '📅 Mis citas' },
          { id: 'blocks',       label: '⏰ Mis horarios' },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            style={{ flex: 1, padding: '12px 0', background: 'none', border: 'none', cursor: 'pointer', color: tab === t.id ? 'var(--gold)' : 'var(--gray)', borderBottom: tab === t.id ? '2px solid var(--gold)' : '2px solid transparent', fontSize: 13, fontWeight: 600, transition: 'all 0.2s' }}>
            {t.label}
          </button>
        ))}
      </div>

      <div style={{ maxWidth: 520, margin: '0 auto', padding: '20px 16px' }}>

        {/* TAB CITAS */}
        {tab === 'appointments' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <h2 className="fc-title" style={{ fontSize: 22, color: 'var(--gold)' }}>Mis citas</h2>
              <input type="date" value={date} onChange={e => setDate(e.target.value)} className="fc-input" style={{ width: 'auto', fontSize: 13 }} />
            </div>

            {loading ? (
              <div style={{ textAlign: 'center', padding: 40, color: 'var(--gray)' }}>Cargando...</div>
            ) : appointments.length === 0 ? (
              <div style={{ textAlign: 'center', padding: 40, color: 'var(--gray)' }}>
                <div style={{ fontSize: 40, marginBottom: 8 }}>😊</div>
                No tienes citas este día
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {appointments.map(a => {
                  const stl = STATUS_LABELS[a.status];
                  return (
                    <div key={a.id} className="fc-card" style={{ padding: 16 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 16 }}>{a.client_name}</div>
                          <div style={{ color: 'var(--gray)', fontSize: 12 }}>📞 {a.client_phone}</div>
                        </div>
                        <div className="fc-title" style={{ fontSize: 24, color: 'var(--gold)' }}>{formatTime(a.appointment_time)}</div>
                      </div>
                      <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap', marginBottom: 10 }}>
                        <span style={{ background: 'rgba(201,168,76,0.1)', color: 'var(--gold)', padding: '3px 10px', borderRadius: 8, fontSize: 12 }}>{a.service?.name}</span>
                        <span style={{ background: 'rgba(255,255,255,0.05)', color: 'var(--gray)', padding: '3px 10px', borderRadius: 8, fontSize: 12 }}>{formatPrice(a.total_price)}</span>
                        <span className={stl?.color} style={{ padding: '3px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600 }}>{stl?.label}</span>
                      </div>
                      {a.notes && <div style={{ color: 'var(--gray)', fontSize: 12, marginBottom: 10, fontStyle: 'italic' }}>📝 {a.notes}</div>}
                      {a.status !== 'done' && a.status !== 'cancelled' && (
                        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                          {a.status === 'pending' && <button className="fc-btn-gold" style={{ padding: '7px 14px', fontSize: 12 }} onClick={() => updateStatus(a.id, 'confirmed')}>✅ Confirmar</button>}
                          {(a.status === 'confirmed' || a.status === 'pending') && <button className="fc-btn-gold" style={{ padding: '7px 14px', fontSize: 12 }} onClick={() => updateStatus(a.id, 'in_progress')}>✂️ Atendiendo</button>}
                          {a.status === 'in_progress' && <button className="fc-btn-gold" style={{ padding: '7px 14px', fontSize: 12, background: 'var(--green)', color: 'white' }} onClick={() => updateStatus(a.id, 'done')}>🏁 Listo</button>}
                          <button className="fc-btn-outline" style={{ padding: '7px 12px', fontSize: 12, borderColor: 'rgba(231,76,60,0.4)', color: '#E74C3C' }} onClick={() => updateStatus(a.id, 'cancelled')}>Cancelar</button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB BLOQUEOS */}
        {tab === 'blocks' && barber && (
          <div>
            <h2 className="fc-title" style={{ fontSize: 22, color: 'var(--gold)', marginBottom: 6 }}>Mis horarios</h2>
            <p style={{ color: 'var(--gray)', fontSize: 13, marginBottom: 20 }}>
              Bloquea horas para descansos, almuerzo u otras actividades. Los clientes no podrán reservar esos horarios.
            </p>

            {/* Aviso si está en No disponible */}
            {barber.status === 'off' && (
              <div style={{ background: 'rgba(231,76,60,0.08)', border: '1px solid rgba(231,76,60,0.25)', borderRadius: 10, padding: '14px 16px', marginBottom: 16 }}>
                <div style={{ fontWeight: 700, color: '#E74C3C', fontSize: 14, marginBottom: 4 }}>🔴 Estás como No disponible</div>
                <div style={{ color: 'var(--gray)', fontSize: 12, marginBottom: 10 }}>
                  Los clientes no pueden reservar contigo. Cambia tu estado cuando estés listo para recibir citas.
                </div>
                <button className="fc-btn-gold" style={{ padding: '8px 16px', fontSize: 12 }} onClick={() => setMyStatus('available')}>
                  ✅ Marcarme como disponible
                </button>
              </div>
            )}

            <div className="fc-card" style={{ padding: 16 }}>
              <BlockSchedule barberId={barber.id} barberName={barber.name} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
